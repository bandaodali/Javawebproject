/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lxhc8submarine;

import javafx.scene.layout.AnchorPane;

/**
 *
 * @author Xu
 */
public interface Visualizer {
    
    public void start();
    public void end();
    public String getName();
    public void updateself(AnchorPane vizPane);
    public void update(double location, float[] magnitudes, float[] phases);
           
}
