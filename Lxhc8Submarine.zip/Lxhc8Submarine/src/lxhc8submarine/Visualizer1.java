/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lxhc8submarine;

import static java.lang.Integer.min;
import java.util.ArrayList;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

/**
 *
 * @author Xu
 */
public class Visualizer1 implements Visualizer{

    private String name = "Visualizer1";
    private AnchorPane vizPane;

    public AnchorPane getVizPane() {
        return vizPane;
    }
    
    public void setVizPane(AnchorPane vizPane) {
        this.vizPane = vizPane;
    }
    private ArrayList<Bubble> bubbles =new ArrayList<>();
    private static Integer circleNum = 10;
    private static Integer bubbleInteval = 15;
    private static Double bubbleSize = 1.0;
    private static Integer bubbleSpeed = 5;
    private static Double increaseSize = 0.6;
    @Override
    public void start() {
        end();
        System.out.println("Initialized the bubbles!\n"+"vizpane'height is "+vizPane.getHeight());        
        for(int i = 0; i<circleNum; i++){            
            bubbles.add(new Bubble(15, vizPane.getHeight()-i*bubbleInteval-15, i*increaseSize, i, increaseSize));
            vizPane.getChildren().add(bubbles.get(i));
        }
    }
    @Override
    public void end() {
        if(bubbles!=null){
            for (int i = 0; i < bubbles.size(); i++) {
                vizPane.getChildren().remove(bubbles.get(i));
            }
            bubbles = new ArrayList<Bubble>();
        }
    }
    @Override
    public void updateself(AnchorPane vizPane){
        System.out.println("\n\nBubbles are updating!");
        for (int i = 0; i < bubbles.size(); i++) {
            bubbles.get(i).updateLocation(vizPane);
        }        
    }

    @Override
    public String getName() {
        return name; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(double location, float[] magnitudes, float[] phases) {
        System.out.println("\n\n"+"X's location is " + bubbles.get(0).getCenterX());        
        System.out.println(bubbles.get(0).getIncreaseSize());
        System.out.println(bubbles.get(0).getSpeed());
        Bubble bubble;
        for(int i = 0; i<circleNum; i++){
           bubble  = bubbles.get(i);
           System.out.println("Time is "+bubble.getTimes());
           System.out.println("Before: LocationY is "+bubble.getCenterY());
           bubble.setCenterX(location);
           bubble.setIncreaseSize(increaseSize*((80.0+magnitudes[0])/50.0));          
           bubble.setSpeed(phases[0]/0.4*bubbleSpeed);
           if(bubble.getTimes()>=12){
               bubble.setTimes(0);
               bubble.setRadius(increaseSize);
               bubble.setCenterY(350.0);               
           }
           bubble.setCenterY(bubble.getCenterY()-bubble.getSpeed());
           bubble.setRadius(bubble.getRadius()+bubble.getIncreaseSize());
           bubble.setTimes(bubble.getTimes()+1);
           System.out.println("Radius is "+bubble.getRadius());
           System.out.println("After: LocationY is "+bubble.getCenterY());
        }
        
    }
    
}
