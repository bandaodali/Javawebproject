/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lxhc8submarine;

import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

/**
 *
 * @author Xu
 */
public class Bubble extends Circle {
    private Double speed;
    private Integer times;
    private Double increaseSize;

    public Bubble(double centerX, double centerY, double radius,int times,double increaseSize) {
        super(centerX, centerY, radius);
        this.times = times;
        this.increaseSize = increaseSize;
        this.setCenterX(centerX);
        this.setCenterY(centerY);
        this.setRadius(radius);
        this.setFill(Color.TRANSPARENT);
        this.setStroke(Color.BLACK);
    }
    
    public void updateLocation(AnchorPane pane){
        System.out.println("Time is "+times);
        System.out.println("Before: LocationY is "+getCenterY()+"-"+speed);
        setCenterY(getCenterY()-speed);
        System.out.println("After: LocationY is "+getCenterY());
        setRadius(getRadius()+increaseSize);
        System.out.println("Radius is "+getRadius());
        if(times>12){
            times = 0;
            this.setRadius(increaseSize);
            this.setCenterY(350.0);
        }
        times++;
}

    public Double getIncreaseSize() {
        return increaseSize;
    }

    public void setIncreaseSize(Double increaseSize) {
        this.increaseSize = increaseSize;
    }

    public Double getSpeed() {
        return speed;
    }

    public void setSpeed(Double speed) {
        this.speed = speed;
    }

    public Integer getTimes() {
        return times;
    }

    public void setTimes(Integer times) {
        this.times = times;
    }

}
