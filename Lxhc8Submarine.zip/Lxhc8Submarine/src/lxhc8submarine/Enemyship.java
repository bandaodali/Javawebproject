/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lxhc8submarine;


import java.util.ArrayList;
import javafx.scene.CacheHint;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.paint.*;

/**
 *
 * @author Xu
 */
public class Enemyship extends Ship{

    private Integer level ; // 0 1 2
    private ArrayList<Circle> circles = new ArrayList<>();
    private ArrayList<Line> lines = new ArrayList<>();

    public ArrayList<Circle> getCircles() {
        return circles;
    }

    public void setCircles(ArrayList<Circle> circles) {
        this.circles = circles;
    }

    public ArrayList<Line> getLines() {
        return lines;
    }

    public void setLines(ArrayList<Line> lines) {
        this.lines = lines;
    }


    public Enemyship(String image, Integer speed, Integer locationx, Integer locationy){
        super(image, speed, locationx, locationy);
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }
    
    public void shoot(AnchorPane pane){
        if(level ==1)
            shootTorpedo(pane);
        if(level ==2)
            shootMissles(pane);
    }
    public void shootTorpedo(AnchorPane pane){
        Circle circle = new Circle(this.getLocationX(), this.getLocationY(), 3, Color.YELLOW);
        circles.add(circle);
        pane.getChildren().add(circle);
//        System.out.println("ShootTorpedo------ ");
    } 
    public void shootMissles(AnchorPane pane){
        Line line = new Line(this.getLocationX(), this.getLocationY(), this.getLocationX(), this.getLocationY()-8);
        lines.add(line);
        pane.getChildren().add(line);
//        System.out.println("ShootMissles------ ");
    }
}
