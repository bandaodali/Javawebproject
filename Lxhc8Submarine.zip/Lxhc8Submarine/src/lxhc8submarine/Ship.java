/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lxhc8submarine;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author Xu
 */
public abstract class  Ship extends ImageView{
    private String imagestring;
    private Integer speed;
    private Integer locationx;
    private Integer locationy;
    private Integer direction;
    private Image image;  
    
    public Ship(String imagestring, Integer speed, Integer locationx, Integer locationy){
        System.out.println(imagestring);
        this.imagestring = imagestring ; 
        this.speed = speed ;
        this.locationx = locationx;
        this.locationy = locationy;
        this.image = new Image(this.getClass().getResourceAsStream(imagestring)); 
        this.setImage(image);
        this.setX(locationx);
        this.setY(locationy);
    }

    public Integer getSpeed() {
        return speed;
    }

    public void setSpeed(Integer speed) {
        this.speed = speed;
    }

    public Integer getLocationX() {
        return locationx;
    }

    public void setLocationX(Integer locationx) {
        this.locationx = locationx;
        this.setX(locationx);
    }

    public Integer getLocationY() {
        return locationy;
    }

    public void setLocationY(Integer locationy) {
        this.locationy = locationy;
        this.setY(locationy);
    }
    
    public void setDirection(Integer direction) {
        this.direction = direction;
    }
    
    public Integer getDirection() {
        return direction;
    }
    
    public void move(){
        if (direction==1)
            setLocationX(locationx + speed); 
        if (direction==-1)
            setLocationX(locationx - speed);
    }
    public abstract void shoot(AnchorPane pane);
}
