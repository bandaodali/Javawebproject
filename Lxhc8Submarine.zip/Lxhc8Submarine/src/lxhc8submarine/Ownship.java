/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lxhc8submarine;

import java.util.ArrayList;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;

/**
 *
 * @author Xu
 */
public class Ownship extends Ship {
    private ArrayList<Rectangle> bombs = new ArrayList<>();
    private Integer numberofbomb = 5 ;
    private static int bombwidth = 3 ;
    private static int bombheight = 6 ;
    
    public Integer getNumberofbomb() {
        return numberofbomb;
    }

    public void setNumberofbomb(Integer numberofbomb) {
        this.numberofbomb = numberofbomb;
    }

    public ArrayList<Rectangle> getBombs() {
        return bombs;
    }

    public void setBombs(ArrayList<Rectangle> bombs) {
        this.bombs = bombs;
    }
     public Ownship(String imagestring, Integer speed, Integer locationx, Integer locationy){
        super(imagestring, speed, locationx, locationy);
//        System.out.println(imagestring);
    }
     public void shoot(AnchorPane pane){
         Rectangle rectangle = new Rectangle(bombwidth,bombheight,Color.ORANGE);
         System.out.println(rectangle.getX()+"\t"+rectangle.getY());
         rectangle.setLayoutX(getLocationX()+0.5*getImage().getWidth());
         rectangle.setLayoutY(0);
         bombs.add(rectangle);
         pane.getChildren().add(rectangle);
     }

}
