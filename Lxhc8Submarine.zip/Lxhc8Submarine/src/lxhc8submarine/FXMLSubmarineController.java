/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lxhc8submarine;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Bounds;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @author Xu
 */
public class FXMLSubmarineController implements Initializable {
    
    @FXML
    private VBox vbox;
    @FXML
    private Label label;
    @FXML
    private Text score;
    @FXML
    private Text bomb;
    @FXML
    private AnchorPane wholepane;
    @FXML
    private AnchorPane waterpane;
    @FXML
    private Rectangle waterregion;
    @FXML
    private Rectangle blood1;
    @FXML
    private Rectangle blood2;
    @FXML
    private Rectangle blood3;
    @FXML
    private MediaView mediaView;
    //ship setting
    String enemyType = "level1.PNG";
    Integer enemyDirection = 1;
    Integer enemySpeed = 6;
    Integer torpedoesSpeed = 10;
    Integer misselsSpeed = 15;
    Integer enemyX1 = 0;
    Integer enemyX2 = 600;
    Integer motherspeed = 20;
    Integer motherDirection;
    Integer motherStartx = 280;
    Integer motherStarty = 50;
    //grade setting
    Random rd = new Random();
    Integer rd4hasenemy;
    Integer rd4type;
    Integer chance = 20;
    Integer chance4type = 2;
    Integer throwBullet ;    
    Integer numberofbomb = 5;
    Integer timetofill;
    Integer awards = 100;
    //game setting
    Integer scores = 0;
    Integer intervelofBombs = 2000;
    ArrayList<Enemyship> enemys = new ArrayList<>();
    ArrayList<Line> missels = new ArrayList<>();
    ArrayList<Circle> torpedoes = new ArrayList<>();
    File musicFile = new File("src\\lxhc8submarine\\Sleep Away.mp3");
    ArrayList<Rectangle> bloods;
    Integer bulletspeed ;
    Integer timelineCount = 0; 
    Boolean whetherPause = false;
    Ownship ownship = new Ownship("mothership.jpg", motherspeed, motherStartx, motherStarty);;
    Media media;
    MediaPlayer mediaPlayer;
    Visualizer1 currentVisualizer = new Visualizer1();
    
    Timeline timeline1 = new Timeline(
            new KeyFrame(Duration.millis(50), (ActionEvent actionEvent) ->{
                    
                    if (timelineCount%2==0){
                        updateEnemy();
                    }
                    if (timelineCount%2==1){
                        updateYourBomb();
                    }
                    if (timelineCount%40==0){
                        update();
                        addBomb(ownship);
                    }                  
                timelineCount++;
            })
    );
    
//    Timeline timeline2 = new Timeline(
//            new KeyFrame(Duration.millis(50), (ActionEvent actionEvent) ->{
//                    updateEnemy();                 
//            })
//    );    
//    Timeline timeline3 = new Timeline(
//            new KeyFrame(Duration.millis(50), (ActionEvent actionEvent) ->{
//                    updateYourBomb();
//            })
//    );

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        bloods = new ArrayList<Rectangle>();
        bloods.add(blood1);
        bloods.add(blood2);
        bloods.add(blood3);
        
    }
    @FXML
    private void changeEasy(){
        chance4type = 2 ;
        chance = 20;
        if (ownship != null){
            ownship.setNumberofbomb(5);
        }
        numberofbomb = 5;
        bomb.setText(numberofbomb+"");
        awards = 100;
        enemySpeed = 4;
        torpedoesSpeed = 10;
        misselsSpeed = 15;

    }
    @FXML
    private void changeMedium(){
        chance4type = 3 ;
        chance = 10;
        if (ownship != null){
            ownship.setNumberofbomb(4);
        }
        numberofbomb = 4;
        bomb.setText(numberofbomb+"");
        awards = 120;
        intervelofBombs = 3000;
        enemySpeed = 5;
        torpedoesSpeed = 15;
        misselsSpeed = 20;

    }
    @FXML
    private void changeHard(){
        chance4type = 3;
        chance = 5;
        if (ownship != null){
            ownship.setNumberofbomb(2);
        }
        numberofbomb = 2;
        bomb.setText(numberofbomb+"");
        awards = 200;
        intervelofBombs = 4000;
        enemySpeed = 7;
        torpedoesSpeed = 20;
        misselsSpeed = 25;


    }
    public void ready(Stage stage){
         
         
         stage.addEventFilter(KeyEvent.KEY_PRESSED, (KeyEvent event) -> {
            if ("RIGHT".equals(event.getCode().toString())) {                
                if(ownship.getX()<600){
                    ownship.setDirection(1);
                    ownship.move();
                }
//                System.out.println("RIGHT");
            }
            else if ("LEFT".equals(event.getCode().toString())) {
                if(ownship.getX()>0){                    
                    ownship.setDirection(-1);
                    ownship.move();
                    }
//                System.out.println("LEFT");
            }
            else if ("SPACE".equals(event.getCode().toString())){
                if(ownship.getNumberofbomb()>0){
                    ownship.shoot(waterpane);
                    ownship.setNumberofbomb(ownship.getNumberofbomb()-1);
                    bomb.setText(ownship.getNumberofbomb()+"");
                }
            }
            else if ("F10".equals(event.getCode().toString())){
                handpause();
            }
            if ("F11".equals(event.getCode().toString())){
                resetScane();
            }
        });
    } 
    @FXML
    private void handstart(){
        currentVisualizer.setVizPane(wholepane);
        wholepane.getChildren().remove(label);
        wholepane.getChildren().add(ownship);
        ownship.setNumberofbomb(numberofbomb);
        timeline1.setCycleCount(Animation.INDEFINITE);
        timeline1.play();
        openMedia(musicFile);
//        timeline2.setCycleCount(Animation.INDEFINITE);
//        timeline2.play();
//        timeline3.setCycleCount(Animation.INDEFINITE);
//        timeline3.play();
        
    }
    public void handpause(){
        if(!whetherPause){
            timeline1.pause();
            mediaPlayer.pause();
            whetherPause = true ;
        }
        else{
            timeline1.play();
            mediaPlayer.play();
            whetherPause = false ;
        }
//        timeline2.pause();
    }
    
    public void update(){
        Enemyship enemy;
        for (int i = 0; i < 9; i++) {
            rd4hasenemy = rd.nextInt(chance*2);
            enemyDirection = -enemyDirection;
            if (rd4hasenemy == 0|| rd4hasenemy == chance * 2-1){
                rd4type = rd.nextInt(chance4type);
                switch(rd4type){
                    case 0 :                        
                        if (enemyDirection == 1){
                            enemyType = "level1_1.jpg";
                            enemy = new Enemyship(enemyType, enemySpeed, enemyX1, 30*i);
                            enemy.setLevel(rd4type);
                            enemy.setDirection(enemyDirection);
                            enemys.add(enemy);
                            waterpane.getChildren().add(enemy);
                        }
                        else{
                            enemyType = "level1_2.jpg";
                            enemy = new Enemyship(enemyType, enemySpeed, enemyX2, 30*i);
                            enemy.setLevel(rd4type);
                            enemy.setDirection(enemyDirection);
                            enemys.add(enemy);
                            waterpane.getChildren().add(enemy);
                        }
                        break;
                    case 1:                                                
                        if (enemyDirection == 1){
                            enemyType = "level2_1.jpg";
                            enemy = new Enemyship(enemyType, enemySpeed, enemyX1, 30*i);
                            enemy.setLevel(rd4type);
                            enemy.setDirection(enemyDirection);
                            enemys.add(enemy);
                            waterpane.getChildren().add(enemy);
                        }
                        else{
                            enemyType = "level2_2.jpg";
                            enemy = new Enemyship(enemyType, enemySpeed, enemyX2, 30*i);
                            enemy.setLevel(rd4type);
                            enemy.setDirection(enemyDirection);
                            enemys.add(enemy);
                            waterpane.getChildren().add(enemy);
                        }
                        break;
                    case 2:                        
                        if (enemyDirection == 1){
                            enemyType = "level3_1.jpg";
                            enemy = new Enemyship(enemyType, enemySpeed, enemyX1, 30*i);
                            enemy.setLevel(rd4type);
                            enemy.setDirection(enemyDirection);
                            enemys.add(enemy);
                            waterpane.getChildren().add(enemy);
                        }
                        else{
                            enemyType = "level3_2.jpg";
                            enemy = new Enemyship(enemyType, enemySpeed, enemyX2, 30*i);
                            enemy.setLevel(rd4type);
                            enemy.setDirection(enemyDirection);
                            enemys.add(enemy);
                            waterpane.getChildren().add(enemy);
                        }
                        break;
                }                           
            }
        }        
    }
    private void updateEnemy(){
        int i ; 
        Enemyship enemy;
        int j ;
        for (i = 0 ; i<enemys.size();i++) {
            enemy = enemys.get(i);
            throwBullet = rd.nextInt(chance);
            if (throwBullet == 0) {
                enemy.shoot(waterpane);
                if(enemy.getLevel()==1){
                    torpedoes.add(enemy.getCircles().get(enemy.getCircles().size()-1));
                }
                if(enemy.getLevel()==2){
                    missels.add(enemy.getLines().get(enemy.getLines().size()-1));
                }
            }            
            enemy.move();
            if(enemy.getLocationX()>600||enemy.getLocationX()<0){
                 enemys.remove(enemy);
                 waterpane.getChildren().remove(enemy);
            }
        }
        Circle circle;
        for (j = 0 ; j<torpedoes.size(); j++){
            circle = torpedoes.get(j);
            circle.setCenterY(circle.getCenterY()-torpedoesSpeed);
            whetherHittedbyCircle(circle);
            if(circle.getCenterY()<0){
                torpedoes.remove(circle);
                waterpane.getChildren().remove(circle);
            }
        }
        Line line ;
        for (j = 0 ; j<missels.size(); j++){
            line = missels.get(j);
            line.setStartY(line.getStartY()-misselsSpeed);
            line.setEndY(line.getEndY()-misselsSpeed);
            whetherHittedbyLine(line);
            if(line.getEndY()< 0){
                missels.remove(line);
                waterpane.getChildren().remove(line);
            }
        }
    }
    private void updateYourBomb(){
        int i;
        int j;
        Rectangle bomb;
        Enemyship enemy;
        for (i = 0 ; i<ownship.getBombs().size(); i++){
            bomb = ownship.getBombs().get(i);
            for (j = 0 ; j<enemys.size() ; j++) {
                enemy = enemys.get(j);
                if(bomb.getBoundsInParent().intersects(enemy.getBoundsInParent())){
                   
                        System.out.println("BOMB___!");
                        ownship.getBombs().remove(bomb);
                        waterpane.getChildren().remove(bomb);
                        i--;
                        enemys.remove(enemy);
                        waterpane.getChildren().remove(enemy);
                        j--;
                        scores += awards * (enemy.getLevel()+1);
                        score.setText(Integer.toString(scores));
                    
                }
            }
            if(bomb.getY()>300){
                ownship.getBombs().remove(bomb);
                waterpane.getChildren().remove(bomb);
                i--;
            }
            bomb.setY(bomb.getY()+5);            
        }      
    }
    
    public void addBomb(Ownship ship){
        if(ownship.getNumberofbomb()<numberofbomb){
            ownship.setNumberofbomb(ownship.getNumberofbomb()+1);
            bomb.setText(ownship.getNumberofbomb()+"");
        }
    } 

    private void whetherHittedbyCircle(Circle circle){
        if (circle.getCenterY()+2 <= ownship.getY()+ownship.getImage().getHeight()-77){
            if(circle.getCenterX()>=ownship.getX()&&circle.getCenterX()<=ownship.getX()+ownship.getImage().getWidth()){                
                wholepane.getChildren().remove(bloods.get(0));
                bloods.remove(0);
                //add sound
                waterpane.getChildren().remove(circle);
                whetherEnd();
            }
        }
    }
     private void whetherHittedbyLine(Line line){
        if (line.getEndY() <= ownship.getY()+ownship.getImage().getHeight()-77){
            if(line.getEndX()>=ownship.getX()&&line.getEndX()<=ownship.getX()+ownship.getImage().getWidth()){                
                wholepane.getChildren().remove(bloods.get(0));
                bloods.remove(0);
                whetherEnd();
            }
        }
    }
     private void whetherEnd(){
         if(bloods.size() == 0){
             int savescore = scores ;
             resetScane();
             openWindowafterEnd(savescore);
         }
     }
     private void bombSpecial(Enemyship enemy){
         Double startx = enemy.getX()+0.5*enemy.getImage().getWidth();
         Double starty = enemy.getY()+0.5*enemy.getImage().getHeight();
         ArrayList<Line> lines = new ArrayList<>();
         lines.add(new Line(startx+5, starty, startx+20, starty));
         lines.add(new Line(startx+3, starty+3, startx+12, starty+12));
         lines.add(new Line(startx, starty+5, startx, starty+20));
         lines.add(new Line(startx-3, starty+3, startx-12, starty+12));
         lines.add(new Line(startx-5, starty, startx-20, starty));
         lines.add(new Line(startx-3, starty-3, startx-12, starty-12));
         lines.add(new Line(startx, starty-5, startx+20, starty-20));
         lines.add(new Line(startx+3, starty-3, startx+12, starty-12));
         for(Line line: lines){
             waterpane.getChildren().add(line);
         }
        int i ;
        for(i = 0;i<lines.size();i++){
            waterpane.getChildren().remove(lines.get(i));
            lines.remove(lines.get(i));
            i--;
        } 
     }

     private void openWindowafterEnd(int scores){
         handleEndOfMedia();
         ArrayList<String> arrStream = new ArrayList<>();
         ArrayList<String> nameStream = new ArrayList<>();
         ArrayList<Integer> scoreStream = new ArrayList<>();
        try {
            Scanner in = new Scanner(new FileReader("src\\lxhc8submarine\\record.txt"));
            int i = 0 ;
            while(in.hasNext()){
                arrStream.add(in.next());
                if(i%2==0){
                    nameStream.add(arrStream.get(i));
//                    System.out.print(arrStream.get(i)+"\t");
                }
                else{
                    scoreStream.add(Integer.parseInt(arrStream.get(i)));
//                    System.out.print(arrStream.get(i)+"\n");
                }
                i+=1;
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLSubmarineController.class.getName()).log(Level.SEVERE, null, ex);
        }
         GridPane root = new GridPane();
         
         Label orderhead = new Label("0         ");
         Label namehead = new Label("name        ");
         Label recordhead = new Label("score");
         root.add(orderhead, 0, 0);
         root.add(namehead, 1, 0);
         root.add(recordhead, 2, 0);
         
         ArrayList<Label> orders =new ArrayList<>();         
         ArrayList<Label> names =new ArrayList<>();
         TextField addName = new TextField(); 
         ArrayList<Label> records =new ArrayList<>();
         Label addRecord = new Label(); 
         int isRecord = 0;
         int i ;
         Button btn = new Button("save");
         boolean unlocked = true;
         for(i = 0; i<arrStream.size();i+=2){
             orders.add(new Label(Integer.toString(i/2+1+isRecord)));
             root.add(orders.get(i/2+isRecord),0,i/2+isRecord+1);             
             if(scores>scoreStream.get(i/2)&&unlocked){                  
                 root.add(addName,1,i/2+1);  
                 addRecord.setText(Integer.toString(scores));
                 root.add(addRecord,2,i/2+1);
                 root.add(btn,3,i/2+1);
                 isRecord++;
                 i-=2;
                 unlocked = false;
             }
             else{
                 names.add(new Label(nameStream.get(i/2)));
                 root.add(names.get(i/2),1,i/2+isRecord+1);
                 records.add(new Label(Integer.toString(scoreStream.get(i/2))));
                 root.add(records.get(i/2),2,i/2+isRecord+1);
             }        
         }
         if(isRecord ==0){
             root.add(new Label(Integer.toString(i/2+1)),0,i/2+1);
             root.add(addName,1,i/2+1);
             addRecord.setText(Integer.toString(scores));
             root.add(addRecord,2,i/2+1);
             root.add(btn,3,i/2+1);
             isRecord = 1 ;
         }
         root.setAlignment(Pos.TOP_CENTER);
         btn.setOnAction(new EventHandler<ActionEvent>() {

             public void handle(ActionEvent event) {
                 btn.setVisible(false);
//             scoreStream.add(scores);
//             nameStream.add(addName.getText());
                 Integer ex1 = scores;
                 String ex2 = addName.getText();
                 System.out.println(ex2+"\t"+ex1);
                 int j = 0;
                 boolean judge = true;
                 for(j = 0; j<scoreStream.size(); j++){
                     if(scoreStream.get(j)<scores&&judge){
                         scoreStream.add(j, scores);
                         nameStream.add(j,ex2);
                         judge = false;
                     }
                 }
                 if (judge){
                     scoreStream.add(scores);
                     nameStream.add(ex2);
                 }
                 try {
                     FileWriter writer = new FileWriter("src\\lxhc8submarine\\record.txt");
                     for(j = 0; j<scoreStream.size(); j++){                         
                         writer.write(nameStream.get(j)+"\t");
                         writer.write(Integer.toString(scoreStream.get(j))+"\n");
                     }
                     writer.close();
                 } catch (IOException ex) {
                     Logger.getLogger(FXMLSubmarineController.class.getName()).log(Level.SEVERE, null, ex);
                 }
             }
         });
         Scene scene = new Scene(root, 400, 500);
         Stage stage = new Stage();
         stage.setTitle("End of Game");
         stage.setScene(scene);
         stage.show();
         
     }
     @FXML
     private void resetScane(){
         mediaPlayer.stop();
         timeline1.stop();
//         timeline2.stop();
         wholepane.getChildren().remove(ownship);
         ownship.setX(motherStartx);
         ownship.setY(motherStarty);
         int i ;
         Rectangle bomb;
         for (i=0;i<ownship.getBombs().size();i++){
             bomb = ownship.getBombs().get(i);
             waterpane.getChildren().remove(bomb);
             i--;
             ownship.getBombs().remove(bomb);
         }
         Enemyship enemy;
         for (i=0;i<enemys.size();i++){
             enemy = enemys.get(i);
             int j;
             Line line;
             for (j=0 ; j<enemy.getLines().size(); j++){
                 line = enemy.getLines().get(j);
                 waterpane.getChildren().remove(line);
                 enemy.getLines().remove(line);
                 j--;
             } 
             Circle circle;
             for (j=0 ; j<enemy.getCircles().size(); j++ ) {
                 circle = enemy.getCircles().get(j);
                 waterpane.getChildren().remove(circle);
                 enemy.getCircles().remove(circle);
                 j--;
             }
             waterpane.getChildren().remove(enemy);
             enemys.remove(enemy);
             i--;
         }
         Rectangle blood;
         for(i=0;i<bloods.size();i++){
             blood = bloods.get(i);
             wholepane.getChildren().remove(blood);
             bloods.remove(blood);
             i--;
         }
         bloods.add(blood1);
         wholepane.getChildren().add(blood1);
         bloods.add(blood2);
         wholepane.getChildren().add(blood2);
         bloods.add(blood3);
         wholepane.getChildren().add(blood3);
         scores = 0 ;
         score.setText(scores+"");
         this.bomb.setText(numberofbomb+"");
     }
     @FXML
     public void aboutME(){
         Stage stage = new Stage();
         stage.setTitle("About ME");
         VBox pane = new VBox();
         Text info1 = new Text("Author   :   Li Xu"+"\n"+"Self Introduction: a 3-year-old programmer"+"\n"+"love game playing and game design!!"+"\n");
         info1.setFont(Font.font("Verdana", FontWeight.BOLD, 15));
         Text info2 = new Text("About Games: Start or Pause in the control menu"+"\n\n"+ "Level menu can set 3 levels, higher grades, higher speeds of enemys and higherbonus."+"\n\n"+"←is left  →isright  Space is throw bombs  F10 is pause  F11 can reset");
         info2.setFill(Color.BLUEVIOLET);
         pane.getChildren().addAll(info1,info2);
         Scene scene = new Scene(pane, 700, 400, Color.YELLOW);
         stage.setScene(scene);
         stage.show();
      }
     
      private void openMedia(File file) {          
          if (mediaPlayer != null) {
              mediaPlayer.dispose();            
          }
          media = new Media(musicFile.toURI().toString());
          mediaPlayer = new MediaPlayer(media);
          mediaView.setMediaPlayer(mediaPlayer);
          mediaPlayer.setOnReady(() -> {
              handleReady();
                
          });
          mediaPlayer.setOnEndOfMedia(() -> {
              handleEndOfMedia();
          });
          mediaPlayer.setAudioSpectrumListener((double timestamp, double duration, float[] magnitudes, float[] phases) -> {
              handleUpdate(timestamp, duration, magnitudes, phases);
          });
          mediaPlayer.setAutoPlay(true);
      }
      private void handleReady() {
          currentVisualizer.start();
      }
      private void handleEndOfMedia() {
          mediaPlayer.stop();
          mediaPlayer.seek(Duration.ZERO);
      }
      private void handleUpdate(double timestamp, double duration, float[] magnitudes, float[] phases) {
          Duration ct1 = mediaPlayer.getCurrentTime();
          Duration ct2 = mediaPlayer.getTotalDuration();
          double location = ct1.toMillis()/ct2.toMillis()*waterpane.getWidth()*0.9+15;
          currentVisualizer.update(location, magnitudes, phases);
      }

}
