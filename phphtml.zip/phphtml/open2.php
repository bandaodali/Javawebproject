<?php
$dbhost = 'localhost:3306'; // database host
$dbuser = 'user'; // database user
$dbpass = '123456'; // database password
$dbname = 'final'; // database name

$mysqli = new mysqli($dbhost,$dbuser,$dbpass,$dbname);

if (!$mysqli) {
    die ('Error connecting to mysql. :-( <br/>');
}
?>