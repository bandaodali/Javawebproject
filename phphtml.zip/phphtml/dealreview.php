<html>
<body>
<?php
include 'open2.php';
session_start();
echo "Thanks,". $_SESSION['username'];
$rid= $_SESSION['rid'];
$rname= $_SESSION['rname'];
$username = $_SESSION['username'];
$score = $_POST["score"];
$content = $_POST["content"];
$time = date("Y-m-d H:i:s");

$sql1 = "select sum(reviews_rating),count(*) from reviews where reviews_rid = '$rid'";
$mysqli->multi_query($sql1);
$res = $mysqli->store_result();
$num_rows = mysqli_num_rows($res);
$value = $score;
if($num_rows > 0){
    $row = $res->fetch_row();
    if ($row[0] != null){
        $value = ($row[0] + $score) / ($row[1] + 1);
    }
}
$sql2 = "UPDATE restaurants SET r_rating = Round('$value',2) where r_id = '$rid';";
$mysqli->multi_query($sql2);
$sql3 = "INSERT INTO reviews (reviews_rid,reviews_user_name,reviews_rating,reviews_text,reviews_time_created)
 VALUES ('$rid','$username','$score','$content','$time');";
$mysqli->multi_query($sql3);
$mysqli->close();
echo "<meta http-equiv='refresh' content='1; url=selection.php' />";
?>

</body>
</html>
