<html>
<body>
<?php
/*include("jpgraph/src/jpgraph.php");
include("jpgraph/src/jpgraph_bar.php");
include("jpgraph/src/jpgraph_line.php");*/

include 'open2.php';
$rid = $_GET["rid"];
$rname = $_GET["rname"];
session_start();
$_SESSION['rid'] = $rid ;
$_SESSION['rname'] = $rname ;
$arrx = array();
echo "<h2 style=\"text-align:center\"><font color = #20b2aa>$rname  </font>";
$sql = "select reviews_user_name,reviews_rating,reviews_text,reviews_time_created 
from reviews where reviews_rid = '$rid' order by reviews_time_created";
$mysqli->multi_query($sql);
$res = $mysqli->store_result();
if ($res) {
    $num_rows = mysqli_num_rows($res);
    echo "<table align=\"center\" width=\"500\" border=\"1px solid black\">";
    echo "<tr><th>username</th><th>score</th><th>content</th><th>time</th></tr>";
    while ($row = $res->fetch_row()) {
        $arrx[] = $row[1];
        printf("<tr><td>".$row[0]."</td><td>" .$row[1]."</td><td>".$row[2]."</td><td>" .$row[3]."</td></tr>");
    }
    echo "</table>";
    $res->free();
}
$mysqli->close();
?>
<h2 style="text-align: center">Write your review</h2>
<div style="width:100%;text-align:center">
<form action="dealreview.php" method="post" style="text-align:center">
    score:
    <input name="score" type="radio" value=1 />1
    <input name="score" type="radio" value=2 />2
    <input name="score" type="radio" value=3 />3
    <input name="score" type="radio" value=4 />4
    <input name="score" type="radio" value=5 />5<br />
    content: <input type="text" name="content"> <br>
    <input name="submit" type="submit" value="submit">
</form>
</div>
</body>
</html>