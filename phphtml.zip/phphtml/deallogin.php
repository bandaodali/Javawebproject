<html>
<body>
<?php
include 'open2.php';
$username = $_POST["username"];
$password = $_POST["password"];
$sql = "select password from user where username = '$username' and password='$password';";
$mysqli->multi_query($sql);
$res = $mysqli->store_result();
$num_rows = mysqli_num_rows($res);
if ($num_rows > 0) {
    session_start();
    $_SESSION['username'] = $username;
    echo "Loading...";
    echo "<meta http-equiv='refresh' content='1; url=selection.php' />";
}
else {
    echo "username or password is wrong";
}
?>
</body>
</html>