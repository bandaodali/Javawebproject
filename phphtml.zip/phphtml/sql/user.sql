-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2017 at 05:55 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `final`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(45) NOT NULL,
  `gender` varchar(2) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `gender`, `password`) VALUES
('aa', 'F', '123456'),
('Amy P.', 'F', NULL),
('April C.', 'F', NULL),
('Arshad A.', 'F', NULL),
('Ashley S.', 'F', NULL),
('Ayo F.', 'F', NULL),
('Caity A.', 'M', NULL),
('Chad L.', 'M', NULL),
('Daniel K.', 'M', NULL),
('Dee D.', 'F', NULL),
('Diana D.', 'F', NULL),
('Dimitrios D.', 'M', NULL),
('Dwayne G.', 'M', NULL),
('Elissa G.', 'F', NULL),
('Elliott W.', 'M', NULL),
('Erik H.', 'M', NULL),
('Faris A.', 'M', NULL),
('Fox E.', 'M', NULL),
('Grace Mao W.', 'M', NULL),
('Hannah W.', 'F', NULL),
('Ian W.', 'M', NULL),
('Isaiah W.', 'M', NULL),
('Jason R.', 'M', NULL),
('Jay L.', 'M', NULL),
('Ji T.', 'M', NULL),
('Jodie Z.', 'M', NULL),
('John W.', 'M', NULL),
('Joseph C.', 'M', NULL),
('Jude T.', 'M', NULL),
('Layne M.', 'M', NULL),
('Lena K.', 'F', NULL),
('li', 'M', '123456'),
('Luke L.', 'M', NULL),
('Maggy D.', 'F', NULL),
('Mich G.', 'M', NULL),
('Michael M.', 'M', NULL),
('Minaz M.', 'M', NULL),
('Nancy N.', 'F', NULL),
('Nia L.', 'F', NULL),
('Nicole G.', 'F', NULL),
('Nik B.', 'M', NULL),
('Quin A.', 'F', NULL),
('Rachel C.', 'F', NULL),
('Rachel L.', 'F', NULL),
('Rachel M.', 'F', NULL),
('Rachel U.', 'F', NULL),
('Raj G.', 'M', NULL),
('Robin P.', 'M', NULL),
('Stephanie L.', 'F', NULL),
('Teri P.', 'F', NULL),
('Thomas B.', 'M', NULL),
('Thomas L.', 'M', NULL),
('William S.', 'M', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
