<html>
<body>

<?php
include 'open2.php';
//$value = $_POST["good[]"];
// 执行多个 SQL 语句
session_start();
$username = $_SESSION['username'];
echo "<p style = 'text-align:right'>Welcome: $username ";
echo "<a href = 'login2.html'>logout</a></p>";
echo "<h3 style=\"text-align:center\"> Restaurant List </h3>";


$sql = "SELECT r_name, r_price,r_distance, r_transactions,r_rating, r_location_address,r_phone,r_id, r_image_url from restaurants";
$sql1 = " where r_transactions = 'delivery'";
$sql2 = " order by";
if(!empty($_POST["type"])){
    $array = $_POST["type"];
    $size = count($array);
    for($i=0; $i< $size; $i++){
        if($array[$i] == "1") $sql = $sql.$sql1;
        if($array[$i] == "2") $sql2 = $sql2." r_price";
        if($array[$i] == "3"){
            if ($sql2 == " order by"){
                $sql2 = $sql2." r_rating";
            } else{
                $sql2 = $sql2.",r_rating";
            }
        }
        if($array[$i] == "4") {
            if ($sql2 == " order by"){
                $sql2 = $sql2." r_distance";
            } else{
                $sql2 = $sql2.",r_distance";
            }
        }
    }
}
if ($sql2 != " order by") $sql = $sql.$sql2;
$sql = $sql.";";
$mysqli->multi_query($sql);
$res = $mysqli->store_result();
if ($res) {
    $num_rows = mysqli_num_rows($res);
    echo "<table align=\"center\" width=\"500\" border=\"1px solid black\">";
    echo "<tr><th>picture</th></th><th>name</th><th>price</th><th>distance(m)</th><th>isdelivery</th>
        <th>score</th><th>address</th><th>telphone</th></tr>";
    while ($row = $res->fetch_row()) {
        printf("<tr><td><a href= $row[8]><img src=$row[8] height='50' width='50'/></a></td>
        <td>".$row[0]."</td><td>" .$row[1]."</td><td>".$row[2]."</td><td>" .$row[3]."</td>
        <td>".$row[4]."</td><td>" .$row[5]."</td><td>".$row[6]."</td>
        <td><a href='review.php?rid=$row[7]&rname=$row[0]'>review</a></td>
        </tr>");
    }
    echo "</table>";
    $res->free();
}
$mysqli->close();
?>
<div style="width:100%;text-align:center">
<form action="selection.php" method="post">
    Sort method <br />
    <label><input name="type[]" type="checkbox" value="1" />isdelivery </label>
    <label><input name="type[]" type="checkbox" value="2" />price </label>
    <label><input name="type[]" type="checkbox" value="3" />score </label>
    <label><input name="type[]" type="checkbox" value="4" />distance </label> <br />
    <input name="submit" type="submit" value="serach">
</form>
</div>
</table>
</body>
</html>